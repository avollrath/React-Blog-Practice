import React, { Component } from 'react'

const Error=()=>{
    return (
        <div>
<p>Error: path does not exist Thank you </p>

        </div>
    )
}

export default Error
